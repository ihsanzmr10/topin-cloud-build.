# TOPIN starter 0.2 — Android agen PPOB + backend

This is a sandbox-first development starter, **not a production financial service**. It does not accept real payments, store customer balances, or fulfill real top-ups. Real transactions remain disabled until authentication, durable idempotency, payment webhooks, ledger posting, reconciliation, provider onboarding, and security/compliance reviews are complete.

## Included
- `android/`: Kotlin + Jetpack Compose Android UI shell.
- `backend/`: TypeScript + Fastify API skeleton.
- `backend/src/providers/digiflazz.ts`: isolated Digiflazz Buyer API adapter that requires explicit sandbox mode and sends `testing: true`; not wired to a public route.
- `backend/db/schema.sql`: PostgreSQL schema for products, orders, payment attempts, double-entry ledger journals, webhook deduplication, and audit events.
- `docs/architecture.md`: payment-vs-fulfillment split, transaction lifecycle, ledger rules, provider references, and security checklist.

## Provider candidates
- **Digiflazz** for PPOB product fulfillment; confirm account eligibility, available products, price list, and test cases with the provider. Official top-up docs: https://developer.digiflazz.com/api/buyer/topup/
- **Xendit** (or another approved Indonesian provider) for QRIS/virtual-account payment collection in test mode. Official docs: https://docs.xendit.co/docs/payments-via-api-overview

These providers have different roles. A payment gateway collecting money does not itself provide the PPOB product catalogue, and a PPOB provider does not automatically provide customer payment collection or bank transfers.

## Run backend locally
Requires Node.js 20+ and PostgreSQL for persistent integration.

```sh
cd backend
npm install
cp .env.example .env
npm run dev
```

Health endpoint: `GET http://localhost:3000/health`.
The transaction endpoint intentionally returns `provider_not_configured`. Do not enable it by removing that guard until the full secure transaction flow is implemented.

## Android build (APK)
1. Install Android Studio and a compatible JDK (use the JDK version required by the project's Android Gradle Plugin).
2. Open the `android/` directory in Android Studio and let Gradle sync.
3. For a local debug APK, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Or from the `android/` directory, run `./gradlew assembleDebug` if a Gradle wrapper has been generated/added; this starter currently may require Android Studio to provision Gradle and SDK components first.
5. Debug APK is normally at `android/app/build/outputs/apk/debug/app-debug.apk` after a successful build.
6. Before connecting a device, configure the backend base URL to an HTTPS deployment. `localhost` on a physical phone refers to the phone itself, not your computer.

## Required before sandbox end-to-end tests
1. Add persistent PostgreSQL repositories and database migrations.
2. Add agent authentication/authorization and rate limits per account/device.
3. Integrate payment provider test mode, verify webhooks, persist event IDs, and verify payment amount/reference.
4. Add a durable queue/outbox for fulfillment and call Digiflazz only after confirmed payment.
5. Use stable idempotency keys and provider references; do not issue a new purchase after a timeout until the original status is checked.
6. Implement balanced ledger posting, refunds/reversals, and reconciliation.
7. Test duplicate requests, webhook replay, pending responses, provider timeouts, wrong amount, expired payment, and failed fulfillment.

## Before production
Obtain provider approval and production credentials, complete security testing and operational monitoring, and confirm applicable Indonesian regulatory and consumer-protection obligations with qualified counsel and the relevant licensed providers. Never store provider secrets in Android. Never present simulated results as real transactions.
