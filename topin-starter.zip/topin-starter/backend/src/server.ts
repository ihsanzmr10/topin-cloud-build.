import Fastify from 'fastify';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import { z } from 'zod';
import { randomUUID } from 'node:crypto';

const app = Fastify({ logger: true, bodyLimit: 16_384 });
await app.register(helmet);
await app.register(rateLimit, { max: 60, timeWindow: '1 minute' });

const products = [
  { id: 'pulsa', name: 'Pulsa', enabled: false, note: 'Enable after provider integration' },
  { id: 'data', name: 'Paket data', enabled: false, note: 'Enable after provider integration' },
  { id: 'electricity', name: 'Token listrik', enabled: false, note: 'Enable after provider integration' },
  { id: 'game', name: 'Voucher game', enabled: false, note: 'Enable after provider integration' },
  { id: 'bank_transfer', name: 'Transfer bank', enabled: false, note: 'Requires approved disbursement partner' },
  { id: 'ewallet', name: 'Transfer e-wallet', enabled: false, note: 'Requires approved disbursement partner' }
];

app.get('/health', async () => ({ status: 'ok', service: 'topin-api', realTransactionsEnabled: false }));
app.get('/v1/products', async () => ({ items: products }));

const transactionSchema = z.object({
  type: z.enum(['pulsa', 'data', 'electricity', 'game', 'bank_transfer', 'ewallet']),
  amount: z.number().int().min(1000).max(50_000_000),
  destination: z.string().trim().min(4).max(120),
  idempotencyKey: z.string().uuid()
});

app.post('/v1/transactions', async (request, reply) => {
  const parsed = transactionSchema.safeParse(request.body);
  if (!parsed.success) return reply.code(400).send({ error: 'invalid_request', details: parsed.error.flatten() });

  // Intentionally fail closed. Do not claim success or debit a fake balance.
  // Replace this with a provider adapter after credentials, webhook verification,
  // idempotency persistence, ledger posting, and reconciliation are implemented.
  return reply.code(503).send({
    error: 'provider_not_configured',
    message: 'Transaksi nyata belum diaktifkan. Hubungkan penyedia resmi melalui backend terlebih dahulu.',
    reference: randomUUID(),
    status: 'not_started'
  });
});

app.setNotFoundHandler(async (_request, reply) => reply.code(404).send({ error: 'not_found' }));

const port = Number(process.env.PORT ?? 3000);
await app.listen({ host: '0.0.0.0', port });
