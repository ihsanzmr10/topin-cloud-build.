import { createHash } from 'node:crypto';

export type DigiflazzResult = {
  ref_id: string;
  customer_no: string;
  buyer_sku_code: string;
  message: string;
  status: 'Sukses' | 'Pending' | 'Gagal' | string;
  rc: string;
  sn?: string;
  price: number;
};

export type DigiflazzConfig = {
  username: string;
  apiKey: string;
  sandbox: boolean;
  baseUrl?: string;
};

/**
 * Digiflazz buyer top-up adapter. Call only from a trusted backend worker after
 * payment has been confirmed and a durable transaction/ref_id has been stored.
 * Sandbox mode is explicit; production mode must be separately reviewed.
 */
export async function submitDigiflazzTopup(input: {
  config: DigiflazzConfig;
  skuCode: string;
  customerNo: string;
  refId: string;
  maxPrice?: number;
}): Promise<DigiflazzResult> {
  const { config, skuCode, customerNo, refId, maxPrice } = input;
  if (!config.username || !config.apiKey) throw new Error('DIGIFLAZZ_CREDENTIALS_MISSING');
  if (!config.sandbox) throw new Error('PRODUCTION_PROVIDER_CALL_BLOCKED_IN_STARTER');
  if (!/^[A-Za-z0-9_-]{8,80}$/.test(refId)) throw new Error('INVALID_PROVIDER_REFERENCE');
  if (!skuCode.trim() || !customerNo.trim()) throw new Error('INVALID_TOPUP_INPUT');

  const sign = createHash('md5').update(config.username + config.apiKey + refId).digest('hex');
  const payload: Record<string, string | boolean | number> = {
    username: config.username,
    buyer_sku_code: skuCode,
    customer_no: customerNo,
    ref_id: refId,
    sign,
    testing: true
  };
  if (maxPrice !== undefined) payload.max_price = maxPrice;

  const response = await fetch(config.baseUrl ?? 'https://api.digiflazz.com/v1/transaction', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(15_000)
  });
  if (!response.ok) throw new Error(`DIGIFLAZZ_HTTP_${response.status}`);
  const body = await response.json() as { data?: DigiflazzResult };
  if (!body.data || body.data.ref_id !== refId || typeof body.data.status !== 'string') {
    throw new Error('DIGIFLAZZ_INVALID_RESPONSE');
  }
  return body.data;
}
