-- TOPIN PostgreSQL starter schema. Use migrations and a controlled deployment in production.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE app_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_e164 TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_verification' CHECK (status IN ('pending_verification','active','restricted','closed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider TEXT NOT NULL,
  provider_sku TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('pulsa','data','electricity','game','postpaid')),
  display_name TEXT NOT NULL,
  sell_price_minor BIGINT CHECK (sell_price_minor > 0),
  provider_cost_minor BIGINT CHECK (provider_cost_minor >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'IDR',
  enabled BOOLEAN NOT NULL DEFAULT false,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(provider, provider_sku)
);

CREATE TABLE transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES app_users(id),
  type TEXT NOT NULL CHECK (type IN ('pulsa','data','electricity','game','postpaid','wallet_topup')),
  product_id UUID REFERENCES products(id),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  fee_minor BIGINT NOT NULL DEFAULT 0 CHECK (fee_minor >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'IDR',
  destination_ciphertext BYTEA NOT NULL,
  status TEXT NOT NULL DEFAULT 'created' CHECK (status IN ('created','awaiting_payment','paid','fulfillment_pending','succeeded','failed','reversed','cancelled','review')),
  provider TEXT,
  provider_reference TEXT,
  payment_provider TEXT,
  payment_reference TEXT,
  idempotency_key UUID NOT NULL,
  failure_code TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, idempotency_key),
  UNIQUE(provider, provider_reference)
);

-- Journal header. Application must post balanced entries in a single DB transaction.
CREATE TABLE ledger_journals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id UUID NOT NULL REFERENCES transactions(id),
  event_key TEXT NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'IDR',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(transaction_id, event_key)
);

-- Append-only double-entry ledger. Never update/delete posted rows; use compensating entries.
CREATE TABLE ledger_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  journal_id UUID NOT NULL REFERENCES ledger_journals(id),
  account_code TEXT NOT NULL,
  direction TEXT NOT NULL CHECK (direction IN ('debit','credit')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL DEFAULT 'IDR',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE payment_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id UUID NOT NULL REFERENCES transactions(id),
  provider TEXT NOT NULL,
  provider_reference TEXT,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  status TEXT NOT NULL CHECK (status IN ('created','pending','paid','expired','failed','refunded','review')),
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(provider, provider_reference)
);

CREATE TABLE webhook_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider TEXT NOT NULL,
  provider_event_id TEXT NOT NULL,
  signature_valid BOOLEAN NOT NULL DEFAULT false,
  payload_sha256 TEXT NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ,
  processing_error TEXT,
  UNIQUE(provider, provider_event_id)
);

CREATE TABLE audit_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id UUID REFERENCES app_users(id),
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  request_id TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX transactions_user_created_idx ON transactions(user_id, created_at DESC);
CREATE INDEX transactions_status_created_idx ON transactions(status, created_at);
CREATE INDEX ledger_entries_journal_idx ON ledger_entries(journal_id);
CREATE INDEX webhook_events_unprocessed_idx ON webhook_events(received_at) WHERE processed_at IS NULL;
