# TOPIN PPOB: transaction architecture (sandbox-first)

## Recommended initial provider split

- **Product fulfillment (pulsa/data/electricity/game): Digiflazz Buyer API** is a candidate. Their documented top-up endpoint is `POST https://api.digiflazz.com/v1/transaction`; the request includes `buyer_sku_code`, `customer_no`, unique `ref_id`, MD5 signature, and optional `testing: true`. A response can be `Sukses`, `Pending`, or `Gagal`. See https://developer.digiflazz.com/api/buyer/topup/.
- **Customer payment collection: Xendit or another approved Indonesian payment provider** is a separate integration. Start with test mode for QRIS/virtual account and verify payment webhooks server-side. Xendit documents test-mode simulation at https://help.xendit.co/hc/en-us/articles/360026743071-Do-you-provide-sandbox-or-account-for-simulation and Payments API at https://docs.xendit.co/docs/payments-via-api-overview.
- These are candidate providers only. Product availability, onboarding, fees, merchant eligibility, and commercial approval must be confirmed directly. Digiflazz fulfillment and Xendit money-in are not the same integration and do not automatically enable transfers/payouts.

## Happy path

1. Android calls backend to create an order with an idempotency key. The backend authenticates the agent, loads product and price from the database, calculates fees, and stores `created`.
2. Backend creates a payment request with the payment provider. Store the provider reference and move order to `awaiting_payment`.
3. Provider webhook arrives. Verify signature/token and timestamp according to that provider's current docs, persist the unique event first, reject duplicate event IDs, and verify amount/currency/reference via provider API when supported.
4. In one DB transaction, mark payment as paid and write a balanced journal for the payment event. Then enqueue fulfillment in a durable queue/outbox.
5. Worker sends the Digiflazz request using a stable unique `ref_id`. Use `testing: true` in sandbox. A timeout is an unknown outcome, not a failure: query/retry according to provider docs with the same reference; never create a new ref for a retry of the same purchase.
6. Map provider result to `succeeded`, `fulfillment_pending`, `failed`, or `review`. Reconcile periodically against provider transaction reports and payment settlement reports.
7. If payment succeeded but fulfillment definitively failed, trigger a refund/reversal workflow and record compensating ledger entries. Do not silently delete ledger rows.

## Ledger rules

- Store IDR as integer rupiah (`BIGINT`), never floating point.
- Journal events are unique by `(transaction_id, event_key)` to prevent duplicate postings.
- Every journal must balance: sum(debits) equals sum(credits) for the same currency. Enforce this in the service layer and a database-safe posting routine before production.
- Keep provider cost, customer payment, provider settlement, fee revenue, refunds, and chargebacks in distinct accounts. A displayed app balance is not proof that funds exist; this agent MVP should not offer a stored customer wallet.
- Never accept prices, payment status, provider status, or account IDs from the Android app as authoritative.

## Security checklist

- Keep provider secrets only in server-side environment/secret manager; rotate keys and use least-privilege scopes.
- Use TLS; Android Network Security Config should disallow cleartext outside local development.
- Add OTP authentication, short-lived access tokens, refresh-token rotation, device/session revocation, and agent role checks before transaction endpoints are enabled.
- Apply rate limits by user/device/IP and transaction type; add velocity/amount limits and anomaly alerts.
- Verify webhook signatures exactly per provider docs; persist event IDs and payload hashes; support replay-safe processing.
- Encrypt destination/customer identifiers at rest; mask them in logs; set retention and access policies.
- Use database transactions, unique idempotency constraints, an outbox/queue, immutable audit events, backups, monitoring, and daily reconciliation.
- Do not collect banking passwords, card PINs, or OTPs. Never ship provider secrets in the APK.
- Review Indonesian legal/compliance requirements with qualified counsel and the licensed provider before production.

## Status

The included provider adapter is sandbox-only and intentionally not exposed by a public transaction endpoint. There is no active payment collection, live fulfillment, production webhook handler, or production-grade authentication in this starter yet.
