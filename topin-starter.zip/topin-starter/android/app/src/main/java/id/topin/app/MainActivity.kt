package id.topin.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF1769FF)
private val Ink = Color(0xFF152238)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Blue)) { TopinHome() } }
    }
}

@Composable
private fun TopinHome() {
    Scaffold(containerColor = Color(0xFFF6F8FC)) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.size(44.dp).background(Blue, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Wallet, contentDescription = null, tint = Color.White)
                }
                Column {
                    Text("TOPIN", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Blue)
                    Text("Top up & transfer", color = Color.Gray, fontSize = 12.sp)
                }
            }
            Column(Modifier.fillMaxWidth().background(Blue, RoundedCornerShape(24.dp)).padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("SALDO AKUN", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                Text("Rp •••••••", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Saldo akan tersedia setelah sistem pembayaran aktif", color = Color.White, fontSize = 12.sp)
            }
            Text("Layanan", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
            val items = listOf(
                Triple("Pulsa & data", Icons.Default.PhoneAndroid, "Top up"),
                Triple("Transfer bank", Icons.Default.AccountBalance, "Transfer"),
                Triple("E-wallet", Icons.Default.SwapHoriz, "Transfer"),
                Triple("Voucher game", Icons.Default.Gamepad, "Top up"),
                Triple("Tagihan", Icons.Default.ReceiptLong, "Bayar"),
                Triple("Isi saldo", Icons.Default.Wallet, "Wallet")
            )
            items.chunked(3).forEach { rowItems ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    rowItems.forEach { item ->
                        Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.fillMaxWidth().padding(vertical = 18.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(item.second, contentDescription = null, tint = Blue, modifier = Modifier.size(28.dp))
                                Text(item.first, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = Ink)
                            }
                        }
                    }
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Transaksi belum aktif", fontWeight = FontWeight.Bold, color = Ink)
                    Text("Ini adalah versi awal. Pembayaran dan transfer nyata akan diaktifkan setelah integrasi mitra resmi dan pengujian keamanan.", color = Color.Gray, fontSize = 12.sp, lineHeight = 18.sp)
                }
            }
        }
    }
}
